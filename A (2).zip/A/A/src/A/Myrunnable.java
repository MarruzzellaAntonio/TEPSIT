package A;

public class Myrunnable implements Runnable{
	
	private int n;
	private Contatore contatore;
	
	Myrunnable(int n, Contatore contatore){ 
		this.n = n;
        this.contatore = contatore;
	}

	public void run() {
		while (contatore.ciSonoNumeri(n)) {
            synchronized (contatore) {
                if (contatore.ciSonoNumeri(n)) {
                    int numero = contatore.getProssimoNumero();
                    System.out.println("Thread " + Thread.currentThread().getName() + " ha stampato: " + numero);
                }
            }
        }
    }
}
