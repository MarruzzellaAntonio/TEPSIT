package A;

import java.util.Scanner;
public class Main {

	public static void main(String[] args) {

		int n;
		int t; //numero di thread
		
		Scanner tastiera = new Scanner(System.in);
		System.out.print("inserisci il numero di thread: ");
		t = tastiera.nextInt();
		
		System.out.print("inserisci il numero a cui vuoi arrivare a contare: ");
		n = tastiera.nextInt();
		
		Contatore contatore = new Contatore();
		for (int i = 0; i<t ; i++) {
			Myrunnable m = new Myrunnable(n, contatore);
			Thread a = new Thread(m);
			a.start();
		}

		tastiera.close();
	}
}
	
