package A;

public class Contatore {
	private int numeroCorrente = 1; 
	
	public synchronized int getProssimoNumero() {
        return numeroCorrente++;
    }

    public synchronized boolean ciSonoNumeri(int n) {
        return numeroCorrente <= n;
    }
}
