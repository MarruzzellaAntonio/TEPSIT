package stato;
import java.util.Random;
import java.util.Scanner;	
public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Inserisci il numero di Thread (T): ");
        int T = scanner.nextInt();
        System.out.print("Inserisci il valore massimo a cui può arrivare a contare il thread(N): ");
        int N = scanner.nextInt();

        CounterThread[] threads = new CounterThread[T];
        for (int i = 0; i < T; i++) {
            threads[i] = new CounterThread(N);
            threads[i].start();
        }

        // Monitoraggio del thread principale
        boolean allCompleted;
        do {
            allCompleted = true;
            System.out.println("Stato dei thread:");
            for (int i = 0; i < T; i++) {
                if (threads[i].isAlive()) {
                    System.out.println("Thread " + i + " - Valore attuale: " + threads[i].getCurrentValue());
                    allCompleted = false; // Ci sono ancora thread attivi
                } else {
                    System.out.println("Thread " + i + " - COMPLETATO");
                }
            }
            try {
				Thread.sleep(1000); // Attende 1 secondo prima di controllare di nuovo lo stato dei thread
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        } while (!allCompleted);

        System.out.println("TUTTI I THREAD COMPLETATI");
    }
}