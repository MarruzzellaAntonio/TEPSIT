package stato;

import java.util.Random;

public class CounterThread extends Thread{
	private int X;  // Valore massimo fino al quale il thread conta
    private int currentValue;    // Valore corrente del conteggio

    public CounterThread(int N) {
        Random random = new Random();
        X = random.nextInt(N + 1);  // X è un numero casuale tra 0 e N
        currentValue = 0;
    }

    public int getCurrentValue() {
        return currentValue;
    }

    public void run() {
        try {
            while (currentValue < X) {
                currentValue++;
                //poi nel caso qui stampi
                Thread.sleep(120); // Aspetta 120 millisecondi tra ogni incremento
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
