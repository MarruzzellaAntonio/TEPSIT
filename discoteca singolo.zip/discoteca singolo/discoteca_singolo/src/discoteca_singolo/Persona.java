package discoteca_singolo;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class Persona extends Thread{
	
	private static AtomicInteger personeDentro = new AtomicInteger(0); //contatore
	
	private Random random = new Random();
    private int id;

    public Persona(int id) {
        this.id = id;
    }

    public void run() {
        while (true) {
            try {
                entra();
                Thread.sleep(random.nextInt(5000));
                esce();
                Thread.sleep(random.nextInt(5000));
                System.out.println("Numero di persone attualmente dentro la discoteca: " + personeDentro.get());//stampa il numero di persone ogni secondo
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void entra() {
        personeDentro.incrementAndGet();
        System.out.println("Persona " + id + " è entrata. Persone dentro: " + personeDentro.get());
    }

    private void esce() {
        personeDentro.decrementAndGet();
        System.out.println("Persona " + id + " è uscita. Persone dentro: " + personeDentro.get());
    }
}
