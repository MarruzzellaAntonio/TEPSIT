package discoteca_singolo;

public class Main {

	public static void main(String[] args) {

        for (int i = 1; i <= 3; i++) {
            Persona persona = new Persona(i);
            persona.start();
        }
    }
}
