/**
 * 
 */
/**
 * 
 */
module discoteca_singolo {
}