package intro_produttore_consumaore;

public class Consumatore implements Runnable{
	private Buffer buffer;
    private int pari;
    private int dispari;

    public Consumatore(Buffer buffer) {
        this.buffer = buffer;
        this.pari = 0;
        this.dispari = 0;
    }

    public void run() {
        try {
            while (true) {
                int numero = buffer.pop(); // Ottiene un numero dal buffer usando pop
                System.out.println("Consumatore ha consumato: " + numero);
                if (numero % 2 == 0) {
                    pari++;
                } else {
                    dispari++;
                }
                System.out.println("Numeri pari: " + pari + ", Numeri dispari: " + dispari);
                Thread.sleep(100); // Attesa di 100ms tra ogni consumazione
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
