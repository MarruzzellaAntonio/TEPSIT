package intro_produttore_consumaore;

import java.util.Random;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

        System.out.print("Inserisci il numero di thread da creare (T): ");
        int T = scanner.nextInt();

        System.out.print("Inserisci il valore massimo di N: ");
        int N = scanner.nextInt();

        Buffer buffer = new Buffer(10);

        Thread produttore = new Thread(new Produttore(buffer));
        produttore.start();

        Thread consumatore = new Thread(new Consumatore(buffer));
        consumatore.start();

        Random random = new Random();
        for (int i = 0; i < T; i++) {
            int X = random.nextInt(N + 1); // X è un numero tra 0 e N
            int finalX = X;
            new Thread(() -> {
                try {
                    for (int j = 0; j <= finalX; j++) {
                        Thread.sleep(120); // Pausa di 120ms ad ogni incremento
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }).start();
        }

        scanner.close();
    }
}

