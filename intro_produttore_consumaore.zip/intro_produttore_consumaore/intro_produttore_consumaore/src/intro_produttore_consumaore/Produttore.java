package intro_produttore_consumaore;

import java.util.Random;

public class Produttore implements Runnable{
	private Buffer buffer;

    public Produttore(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        Random random = new Random();
        try {
            while (true) {
                int numero = random.nextInt(1024); 
                buffer.push(numero); // Inserisce il numero nel buffer usando push
                System.out.println("Produttore ha prodotto: " + numero);
                int waittime = 100 + random.nextInt(901); // Attesa casuale tra 100ms e 1000ms
                Thread.sleep(waittime);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
