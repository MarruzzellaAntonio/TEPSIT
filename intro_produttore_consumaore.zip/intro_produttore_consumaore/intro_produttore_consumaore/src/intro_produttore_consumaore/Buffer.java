package intro_produttore_consumaore;

import java.util.LinkedList;

public class Buffer {
	private LinkedList<Integer> list; // Lista per gestire il buffer
    private final int capacity;

    public Buffer(int capacity) {
        this.list = new LinkedList<>(); // Inizializza la lista
        this.capacity = capacity; // Capacità massima del buffer
    }

    public synchronized void push(int value) throws InterruptedException {
        while (list.size() == capacity) {
            wait(); // Se la lista è piena, aspetta che ci sia spazio
        }
        list.addLast(value); // Aggiunge l'elemento alla fine
        notifyAll(); // Notifica i consumatori che possono leggere
    }

    public synchronized int pop() throws InterruptedException {
        while (list.isEmpty()) {
            wait(); // Se la lista è vuota, aspetta che ci siano nuovi elementi
        }
        int value = list.removeFirst(); // Rimuove il primo elemento
        notifyAll(); // Notifica i produttori che possono aggiungere
        return value;
    }
}
